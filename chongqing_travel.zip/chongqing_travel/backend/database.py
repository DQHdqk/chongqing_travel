import sqlite3

# 数据库文件路径
DB_PATH = 'chongqing.db'

def init_db():
    """初始化数据库，创建表"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # 创建景点表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS scenic (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            image_url TEXT,
            location TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 插入测试数据（如果表是空的）
    cursor.execute("SELECT COUNT(*) FROM scenic")
    count = cursor.fetchone()[0]
    if count == 0:
        cursor.execute("INSERT INTO scenic (name, description, image_url, location) VALUES (?, ?, ?, ?)",
                      ('洪崖洞', '现实版千与千寻，夜景超美', 'hongyadong.jpg', '渝中区'))
        cursor.execute("INSERT INTO scenic (name, description, image_url, location) VALUES (?, ?, ?, ?)",
                      ('解放碑', '重庆地标，抗战胜利纪功碑', 'jiefangbei.jpg', '渝中区'))
        cursor.execute("INSERT INTO scenic (name, description, image_url, location) VALUES (?, ?, ?, ?)",
                      ('磁器口', '千年古镇，陈麻花必买', 'ciqikou.jpg', '沙坪坝区'))
    
    conn.commit()
    conn.close()
    print("数据库初始化完成！")

def get_all_scenic():
    """获取所有景点"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # 让返回结果可以用字段名访问
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, description, image_url, location FROM scenic")
    rows = cursor.fetchall()
    conn.close()
    
    # 转换成字典列表
    result = []
    for row in rows:
        result.append({
            'id': row['id'],
            'name': row['name'],
            'description': row['description'],
            'image': row['image_url'],
            'location': row['location']
        })
    return result