import sqlite3

# 连接数据库（会自动创建文件）
conn = sqlite3.connect('travel.db')
cursor = conn.cursor()

# 创建景点表
cursor.execute('''
    CREATE TABLE IF NOT EXISTS scenic (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        image_url TEXT
    )
''')

# 插入几条测试数据
cursor.execute("INSERT INTO scenic (name, description) VALUES (?, ?)", ('洪崖洞', '现实版千与千寻'))
cursor.execute("INSERT INTO scenic (name, description) VALUES (?, ?)", ('解放碑', '抗战胜利纪功碑'))
cursor.execute("INSERT INTO scenic (name, description) VALUES (?, ?)", ('磁器口', '千年古镇，陈麻花必买'))

# 提交更改并关闭连接
conn.commit()
conn.close()
print("数据库初始化成功！已插入3条景点数据")