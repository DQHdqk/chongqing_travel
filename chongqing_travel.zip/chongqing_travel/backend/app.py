from flask import Flask, jsonify
from flask_cors import CORS
from database import init_db, get_all_scenic  # 导入数据库函数

app = Flask(__name__)
CORS(app)

# 启动时初始化数据库
init_db()

@app.route('/')
def home():
    return '重庆文旅后端API已启动！'

@app.route('/api/scenic', methods=['GET'])
def get_scenic():
    # 从数据库获取真实数据
    scenic_list = get_all_scenic()
    return jsonify(scenic_list)

if __name__ == '__main__':
    app.run(debug=True, port=5000)