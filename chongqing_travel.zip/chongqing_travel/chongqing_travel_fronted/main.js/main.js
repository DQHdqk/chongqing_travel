// 给所有"查看详情"按钮添加点击事件
document.addEventListener('DOMContentLoaded', function() {
    const buttons = document.querySelectorAll('.btn-primary');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const title = this.closest('.card').querySelector('.card-title').textContent;
            alert('你点击了：' + title + '，详情功能开发中~');
        });
    });
});